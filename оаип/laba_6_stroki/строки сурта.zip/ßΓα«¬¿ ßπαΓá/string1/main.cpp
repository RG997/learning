#include <cstdlib>
#include <iostream>
#include <string.h>
#include <stdio.h>

using namespace std;


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	
	char str[30];	
	cout<<"Vvedite stroku ";	
	cin>>str;		
	cout<<"Vasha stroka: "<<str<<endl;
	
	
		system("PAUSE");
		return EXIT_SUCCESS;
	}



